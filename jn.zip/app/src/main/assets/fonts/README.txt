Drop your font here named exactly: custom.ttf
If it's missing, the launcher uses the default font.
